For those column headings that are not explained here, please see the "readme.txt" file of Exp. 1. 

GammaDiff:		the different pairs of gamma distributions that were contrasted and their order of presentation (e.g., "S-F_1" means "slow-fast-1" and refers to the pair of gamma distributions with G1 and G5 as is shown in Fig. 9 of the manuscript. "S-F_2" means "slow-fast-2" and refers to the pair of distributions with G2 and G4.)

Alpha:			the alpha-value computed by the model 

AlphaRec:		the alpha-value computed by the model noted down as string